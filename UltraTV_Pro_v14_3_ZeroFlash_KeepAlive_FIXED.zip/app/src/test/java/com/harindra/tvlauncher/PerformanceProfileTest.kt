package com.harindra.tvlauncher

import org.junit.Assert.assertEquals
import org.junit.Test

class PerformanceProfileTest {

    @Test
    fun detectForRamMb_assignsCorrectTiers() {
        assertEquals(PerformanceTier.ULTRA_LITE, PerformanceTier.detectForRamMb(512L))
        assertEquals(PerformanceTier.LOW_RAM, PerformanceTier.detectForRamMb(1024L))
        assertEquals(PerformanceTier.BALANCED, PerformanceTier.detectForRamMb(2048L))
        assertEquals(PerformanceTier.CINEMATIC, PerformanceTier.detectForRamMb(4096L))
    }
}
