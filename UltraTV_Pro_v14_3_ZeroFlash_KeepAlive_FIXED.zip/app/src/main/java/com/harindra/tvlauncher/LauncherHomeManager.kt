package com.harindra.tvlauncher

import android.app.Activity
import android.app.role.RoleManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

object LauncherHomeManager {

    @Volatile
    var pendingHomeConfirmationCheck: Boolean = false

    private val KNOWN_STOCK_LAUNCHERS = listOf(
        "com.google.android.apps.tv.launcherx",
        "com.google.android.tvlauncher",
        "com.mitv.tvhome",
        "com.tcl.cyberui",
        "com.sony.dtv.homelauncher",
        "com.amazon.tv.launcher",
        "com.hisense.tv.launcher"
    )

    fun isAccessibilityOverrideEnabled(context: Context): Boolean {
        return try {
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: ""
            enabled.contains(context.packageName, ignoreCase = true) &&
                enabled.contains("HomeOverrideAccessibilityService", ignoreCase = true)
        } catch (_: Throwable) { false }
    }

    fun isHomeAliasEnabled(context: Context): Boolean {
        return try {
            val cn = ComponentName(context, "${context.packageName}.HomeLauncherAlias")
            context.packageManager.getComponentEnabledSetting(cn) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
        } catch (_: Throwable) { false }
    }

    fun setHomeAliasEnabled(context: Context, enabled: Boolean) {
        try {
            val cn = ComponentName(context, "${context.packageName}.HomeLauncherAlias")
            val state = if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            context.packageManager.setComponentEnabledSetting(cn, state, PackageManager.DONT_KILL_APP)
        } catch (_: Throwable) { }
    }

    fun isDefaultHomeLauncher(context: Context): Boolean {
        if (isAccessibilityOverrideEnabled(context)) return true
        return try {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val ri = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ri?.activityInfo?.packageName == context.packageName
        } catch (_: Throwable) { false }
    }

    fun getCurrentDefaultHomePackage(context: Context): String {
        if (isAccessibilityOverrideEnabled(context)) return "UltraTV Pro (Accessibility Mode — Zero Popup)"
        return try {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val ri = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ri?.activityInfo?.packageName ?: "HikeenLauncher"
        } catch (_: Throwable) { "HikeenLauncher" }
    }

    fun detectStockLauncherPackage(context: Context): String {
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val matches = context.packageManager.queryIntentActivities(homeIntent, 0)
            for (ri in matches) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg != context.packageName && !pkg.contains("settings", true)) return pkg
            }
        } catch (_: Throwable) { }
        return KNOWN_STOCK_LAUNCHERS.firstOrNull { pkg ->
            try { context.packageManager.getPackageInfo(pkg, 0); true } catch (_: Throwable) { false }
        } ?: "com.google.android.tvlauncher"
    }

    fun checkAndToastConfirmationOnResume(context: Context) {
        if (!pendingHomeConfirmationCheck) return
        pendingHomeConfirmationCheck = false
        if (isAccessibilityOverrideEnabled(context)) {
            Toast.makeText(context, "✅ Confirmed! Accessibility Home Override is ON — Zero Popup Mode Active!", Toast.LENGTH_LONG).show()
        } else if (isDefaultHomeLauncher(context)) {
            Toast.makeText(context, "✅ Confirmed! UltraTV Pro is SAVED as Default Home Launcher!", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(context, "Tip: Turn ON 'UltraTV Pro Home Override' in Accessibility for Zero-Popup Boot!", Toast.LENGTH_LONG).show()
        }
    }

    fun openAccessibilitySettings(activity: Activity) {
        // Ensure HomeAlias is OFF so Android NEVER shows 'Select a Home app' popup!
        setHomeAliasEnabled(activity, false)
        pendingHomeConfirmationCheck = true
        Toast.makeText(activity, "Turn ON 'UltraTV Pro Home Override' -> OK", Toast.LENGTH_LONG).show()
        try {
            activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            openSystemSettingsSafe(activity, Settings.ACTION_SETTINGS)
        }
    }

    fun triggerHomeRoleOrChooser(activity: Activity) {
        setHomeAliasEnabled(activity, true)
        pendingHomeConfirmationCheck = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val rm = activity.getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    Toast.makeText(activity, "Select UltraTV Pro -> Set as Default", Toast.LENGTH_SHORT).show()
                    activity.startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                    return
                }
            } catch (_: Throwable) { }
        }
        val intentsToTry = listOf(
            Intent(Settings.ACTION_HOME_SETTINGS),
            Intent("android.settings.MANAGE_DEFAULT_APPS_SETTINGS"),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (i in intentsToTry) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (i.resolveActivity(activity.packageManager) != null) {
                    Toast.makeText(activity, "Choose 'UltraTV Pro 3D' -> Always", Toast.LENGTH_LONG).show()
                    activity.startActivity(i)
                    return
                }
            } catch (_: Throwable) { }
        }
    }

    fun openRestoreOriginalLauncher(activity: Activity) {
        setHomeAliasEnabled(activity, false)
        Toast.makeText(activity, "Turn OFF 'UltraTV Pro Home Override' in Accessibility to restore original TV launcher", Toast.LENGTH_LONG).show()
        try {
            activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            openSystemSettingsSafe(activity, Settings.ACTION_HOME_SETTINGS)
        }
    }

    fun showSetupWizard(activity: Activity, installedApps: List<AppItem>, onLaunchApp: (AppItem) -> Unit) {
        val accOn = isAccessibilityOverrideEnabled(activity)
        val statusLine = if (accOn) {
            "✅ ZERO-POPUP MODE ACTIVE! UltraTV Pro opens automatically on TV Boot & HOME press!"
        } else {
            "⚠️ Tap 'Enable Zero-Popup (Accessibility)' below — NO Developer Options or ADB needed!"
        }

        AlertDialog.Builder(activity, R.style.GtvDialogTheme)
            .setTitle("Zero-Popup Permanent Home Setup")
            .setMessage(
                "$statusLine\n\n" +
                "RECOMMENDED FOR HIKEEN / LOCKED TVs:\n" +
                "1. Tap 'Enable Zero-Popup (Accessibility)' below.\n" +
                "2. Turn ON 'UltraTV Pro Home Override'.\n" +
                "3. Done! 'Select a Home app' popup will NEVER appear again, and TV boot + HOME key open UltraTV Pro instantly!\n\n" +
                "(You can also use 'Standard Home Chooser' or 'Restore Original' anytime.)"
            )
            .setPositiveButton("Enable Zero-Popup (Accessibility)") { _, _ -> openAccessibilitySettings(activity) }
            .setNeutralButton("Standard Home Chooser") { _, _ -> triggerHomeRoleOrChooser(activity) }
            .setNegativeButton("Restore Original") { _, _ -> openRestoreOriginalLauncher(activity) }
            .show()
    }

    fun showAdbTvGuide(activity: Activity, installedApps: List<AppItem>, onLaunchApp: (AppItem) -> Unit) {
        val stockPkg = detectStockLauncherPackage(activity)
        val cmd = "pm disable-user --user 0 $stockPkg"
        val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        cm?.setPrimaryClip(ClipData.newPlainText("ADB Stock Launcher Command", cmd))
        Toast.makeText(activity, "Copied command for $stockPkg", Toast.LENGTH_SHORT).show()

        AlertDialog.Builder(activity, R.style.GtvDialogTheme)
            .setTitle("Accessibility & ADB Diagnostics ($stockPkg)")
            .setMessage(
                "Zero-Popup Accessibility Mode: ${if (isAccessibilityOverrideEnabled(activity)) "ON (ACTIVE)" else "OFF"}\n" +
                "Detected Factory Launcher: $stockPkg\n" +
                "Optional ADB Command (copied): $cmd"
            )
            .setPositiveButton("Open Accessibility") { _, _ -> openAccessibilitySettings(activity) }
            .setNeutralButton("Developer Options") { _, _ -> openSystemSettingsSafe(activity, Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun openSystemSettingsSafe(activity: Activity, action: String) {
        try {
            activity.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            try { activity.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
        }
    }
}
