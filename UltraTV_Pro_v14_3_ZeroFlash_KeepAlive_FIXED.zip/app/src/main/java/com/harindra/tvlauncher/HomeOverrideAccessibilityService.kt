package com.harindra.tvlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class HomeOverrideAccessibilityService : AccessibilityService() {

    private var stockHomePackages: Set<String> = emptySet()
    private var lastLaunchMs = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        refreshStockHomePackages()
    }

    private fun refreshStockHomePackages() {
        val found = mutableSetOf<String>()
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val list = packageManager.queryIntentActivities(homeIntent, 0)
            for (ri in list) {
                val pkg = ri.activityInfo?.packageName?.lowercase() ?: continue
                if (pkg != packageName.lowercase() && !pkg.contains("settings")) {
                    found.add(pkg)
                }
            }
        } catch (_: Throwable) { }
        stockHomePackages = found
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return super.onKeyEvent(event)
        val prefs = PrefsManager(applicationContext)
        val keyCode = event.keyCode

        // 1. Mapped HOME Button -> Instant UltraTV Pro 3D!
        if (keyCode == KeyEvent.KEYCODE_HOME && prefs.mapHomeToUltraTv) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                launchUltraTvInstant()
            }
            return true
        }

        // 2. Any User-Mapped TV Remote Button (Color keys, TV/Guide, Live, Media, Custom keys!)
        val mappedTarget = prefs.getButtonMapping(keyCode)
        if (mappedTarget.isNotBlank()) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                executeMappedTarget(mappedTarget)
            }
            return true
        }

        return super.onKeyEvent(event)
    }

    private fun executeMappedTarget(target: String) {
        when {
            target == "ultratv_home" -> launchUltraTvInstant()
            target == "tv_settings" -> {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Throwable) { }
            }
            target.startsWith("pkg:") -> {
                val pkg = target.removePrefix("pkg:")
                val launch = packageManager.getLeanbackLaunchIntentForPackage(pkg)
                    ?: packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    try { startActivity(launch) } catch (_: Throwable) { }
                }
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = PrefsManager(applicationContext)
        if (!prefs.mapHomeToUltraTv) return

        val pkg = event.packageName?.toString()?.lowercase() ?: return
        if (pkg == packageName.lowercase()) return
        if (pkg == "android" || pkg == "com.android.systemui" || pkg.contains("settings")) return

        if (stockHomePackages.isEmpty()) {
            refreshStockHomePackages()
        }

        val isStockHome = pkg in stockHomePackages ||
            pkg.contains("hikeen") ||
            pkg == "com.google.android.tvlauncher" ||
            pkg == "com.google.android.apps.tv.launcherx" ||
            pkg == "com.mitv.tvhome" ||
            pkg == "com.tcl.cyberui" ||
            pkg == "com.sony.dtv.homelauncher" ||
            pkg == "com.hisense.tv.launcher" ||
            pkg.endsWith(".tvlauncher") ||
            pkg.endsWith(".launcher") ||
            pkg.endsWith(".launcher3")

        if (isStockHome) {
            launchUltraTvInstant()
        }
    }

    private fun launchUltraTvInstant() {
        val now = System.currentTimeMillis()
        if (now - lastLaunchMs < 150L) return
        lastLaunchMs = now

        // 0ms Black Curtain hides HikeenLauncher flash cleanly!
        BlackCurtainOverlay.show(applicationContext)
        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
        }
        try {
            startActivity(intent)
        } catch (_: Throwable) { }
    }

    override fun onInterrupt() { }
}
